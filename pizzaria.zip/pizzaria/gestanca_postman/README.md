# gestanca_postman

Segue abaixo o modelo da API do sistema de pizzaria

----
Nomes:

André Lucas de Oliveira Santi - RM 94327

Gabriel Henrique Nascimento Paulino Santos - RM 94430

Álvaro Biaggio Pacheco Colognese - RM 93387
