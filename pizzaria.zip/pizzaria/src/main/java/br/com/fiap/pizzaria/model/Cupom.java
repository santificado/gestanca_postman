package br.com.fiap.pizzaria.model;

public class Cupom {
    
    public double desconto;
 }
